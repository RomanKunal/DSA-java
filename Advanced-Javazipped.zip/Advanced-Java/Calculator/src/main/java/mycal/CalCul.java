package mycal;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/CalCul")
public class CalCul extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // This method handles GET requests and performs the calculation
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve parameters from the HTML form
        String num1Str = request.getParameter("num1");
        String num2Str = request.getParameter("num2");
        String operator = request.getParameter("operator");

        // Set response content type to HTML
        response.setContentType("text/html");
        
        // Get the PrintWriter to write the response
        PrintWriter out = response.getWriter();

        // Check if all required parameters are present
        if (num1Str == null || num2Str == null || operator == null) {
            out.println("<h2>Error: Missing input values. Please provide both numbers and an operator.</h2>");
            return;
        }

        double num1 = 0;
        double num2 = 0;
        
        // Try to parse the numbers from the request parameters
        try {
            num1 = Double.parseDouble(num1Str);
            num2 = Double.parseDouble(num2Str);
        } catch (NumberFormatException e) {
            out.println("<h2>Error: Invalid number format. Please enter valid numbers.</h2>");
            return;
        }

        // Perform the calculation based on the operator
        double result = 0;
        boolean validOperator = true;

        switch (operator) {
            case "+":
                result = num1 + num2;
                break;
            case "-":
                result = num1 - num2;
                break;
            case "*":
                result = num1 * num2;
                break;
            case "/":
                if (num2 == 0) {
                    out.println("<h2>Error: Cannot divide by zero.</h2>");
                    return;
                }
                result = num1 / num2;
                break;
            default:
                validOperator = false;
                break;
        }

        // If the operator is invalid, print an error
        if (!validOperator) {
            out.println("<h2>Error: Invalid operator! Please use +, -, *, or /.</h2>");
            return;
        }

        // Print the result
        out.println("<html><body>");
        out.println("<h2>Result: " + result + "</h2>");
        out.println("</body></html>");
    }

    // This method handles POST requests (you can leave it empty or delegate to doGet)
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
