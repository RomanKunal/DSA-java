package ds;
import java.io.IOException;
import java.sql.*;
import java.sql.Statement;
public class Jdbc1 {
    public static void main(String[] args) throws SQLException, IOException {
        // Load the driver
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Driver Loaded");
            Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/employee", "root", "manager");
            System.out.println("Connected to database");
            Statement statement = con.createStatement();
            String createTableQuery = "CREATE TABLE stu (sid INT, name VARCHAR(25), age INT)";
            statement.executeUpdate(createTableQuery);
            System.out.println("Table 'stu' created successfully.");
         
  

        } catch (ClassNotFoundException e) {
            System.out.println("Driver not found: " + e);
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e);
            e.printStackTrace();
        }
    }
}
