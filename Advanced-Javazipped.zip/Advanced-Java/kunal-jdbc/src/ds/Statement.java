package ds;
import java.sql.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
public class Statement {

	public static void main(String[] args) throws SQLException, IOException {
		try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Driver Loaded");
            Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/employee", "root", "manager");
            System.out.println("Connected to database");
            PreparedStatement pt=con.prepareStatement("INSERT INTO stu (sid,name,age)VALUES (?, ?, ?)");
            pt.setInt(1, 1);
            pt.setString(2,"K");
            pt.setInt(3, 19);
            int rowsAffected = pt.executeUpdate();
            System.out.println("Rows inserted: " + rowsAffected);
         
  

        } catch (ClassNotFoundException e) {
            System.out.println("Driver not found: " + e);
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e);
            e.printStackTrace();
        }
		
			
	}

}
