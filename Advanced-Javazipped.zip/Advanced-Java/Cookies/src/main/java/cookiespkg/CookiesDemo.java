package cookiespkg;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class CWork
 */
@WebServlet("/CWork") // Specify the URL pattern to access this servlet
public class CookiesDemo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Display some message in response
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Handle the POST request
		try {
			// Set content type to HTML
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();

			// Get the username parameter from the request
			String n = request.getParameter("username");

			// Display a welcome message
			out.print("Welcome " + n);

			// Create a cookie to store the username
			Cookie ck = new Cookie("uname", n);
			response.addCookie(ck); // Add the cookie to the response

			// Create a form for the next step (servlet2)
			out.print("<form action='servlet2' method='post'>");
			out.print("<input type='submit' value='go'>");
			out.print("</form>");

			// Close the output stream
			out.close();
		} catch (Exception e) {
			// Print any exceptions
			System.out.println(e);
		}
	}
}
